"""
Tyr Backend - llm_service.py
Multi-provider LLM dispatcher for code optimisation.

The backend works with whichever API key is configured in the root `.env`:

  GITHUB_TOKEN   → GitHub Models (Azure AI Inference)  [default model: gpt-4.1]
  GROQ_API_KEY   → Groq                                 [default: llama-3.3-70b-versatile]
  OPENAI_API_KEY → OpenAI direct                        [default: gpt-4o-mini]
  GEMINI_API_KEY → Google Gemini (google-genai SDK)     [default: gemini-2.5-flash]

Auto-detection priority: github > groq > openai > gemini.
Force a specific provider with `TYR_LLM_PROVIDER=<name>`.
Override the model with `TYR_LLM_MODEL=<id>`.
"""

from __future__ import annotations

import json
import logging
import os
import re
import time
from pathlib import Path
from typing import Any

from dotenv import load_dotenv

# ---------------------------------------------------------------------------
# Configuration - load the single root .env
# ---------------------------------------------------------------------------
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
load_dotenv(_PROJECT_ROOT / ".env")

REQUEST_TIMEOUT: int = int(os.getenv("TYR_LLM_TIMEOUT", "120"))
MAX_RETRIES: int = int(os.getenv("TYR_LLM_MAX_RETRIES", "5"))

logger = logging.getLogger("tyr.llm")

# ---------------------------------------------------------------------------
# Provider resolution
# ---------------------------------------------------------------------------

# (provider, env-var, base_url, default-model)
_PROVIDERS: list[tuple[str, str, str, str]] = [
    ("github", "GITHUB_TOKEN",   "https://models.inference.ai.azure.com", "gpt-4.1"),
    ("groq",   "GROQ_API_KEY",   "https://api.groq.com/openai/v1",        "llama-3.3-70b-versatile"),
    ("openai", "OPENAI_API_KEY", "https://api.openai.com/v1",             "gpt-4o-mini"),
    ("gemini", "GEMINI_API_KEY", "",                                      "gemini-2.5-flash"),
]


def _resolve_provider() -> tuple[str, str, str, str]:
    """Return (provider, api_key, base_url, model).

    Honors TYR_LLM_PROVIDER if set; otherwise picks the first provider whose
    env-var is populated. Model can be overridden via TYR_LLM_MODEL or the
    provider-specific TYR_<PROVIDER>_MODEL.
    """
    forced = os.getenv("TYR_LLM_PROVIDER", "").strip().lower()
    model_override = os.getenv("TYR_LLM_MODEL", "").strip()

    if forced:
        for prov, env_var, base, default_model in _PROVIDERS:
            if prov != forced:
                continue
            key = os.getenv(env_var, "").strip()
            if not key:
                raise RuntimeError(
                    f"TYR_LLM_PROVIDER={forced} but {env_var} is not set in .env"
                )
            model = (
                model_override
                or os.getenv(f"TYR_{prov.upper()}_MODEL", "").strip()
                or default_model
            )
            return prov, key, base, model
        raise RuntimeError(
            f"Unknown TYR_LLM_PROVIDER={forced!r}. "
            f"Valid options: {', '.join(p[0] for p in _PROVIDERS)}"
        )

    for prov, env_var, base, default_model in _PROVIDERS:
        key = os.getenv(env_var, "").strip()
        if not key:
            continue
        model = (
            model_override
            or os.getenv(f"TYR_{prov.upper()}_MODEL", "").strip()
            or default_model
        )
        return prov, key, base, model

    raise RuntimeError(
        "No LLM API key configured. Set one of GITHUB_TOKEN, GROQ_API_KEY, "
        "OPENAI_API_KEY, or GEMINI_API_KEY in the root .env file."
    )


# Resolved lazily on first use so import-time failure doesn't kill the server.
_RESOLVED: tuple[str, str, str, str] | None = None
_RESOLVE_ERROR: Exception | None = None


def _get_provider() -> tuple[str, str, str, str]:
    global _RESOLVED, _RESOLVE_ERROR
    if _RESOLVED is not None:
        return _RESOLVED
    if _RESOLVE_ERROR is not None:
        raise _RESOLVE_ERROR
    try:
        _RESOLVED = _resolve_provider()
        prov, _, base, model = _RESOLVED
        logger.info("LLM provider: %s  |  model: %s  |  endpoint: %s",
                    prov, model, base or "(SDK default)")
        return _RESOLVED
    except Exception as exc:
        _RESOLVE_ERROR = exc
        logger.error("LLM provider resolution failed: %s", exc)
        raise


# ---------------------------------------------------------------------------
# System prompts
# ---------------------------------------------------------------------------
SYSTEM_PROMPT: str = (
    "You are an expert algorithm engineer. "
    "The user will provide a code snippet. Your job is to refactor it to "
    "GENUINELY improve its Big-O time complexity (e.g. O(N^2) → O(N log N) or O(N)) "
    "while preserving EXACTLY the same input/output behaviour.\n\n"
    "OPTIMIZATION STRATEGIES you MUST consider:\n"
    "- Replace nested loops with hash-map / dict / set lookups (O(N^2) → O(N))\n"
    "- Use sorting + two-pointer or binary search (O(N^2) → O(N log N))\n"
    "- Use prefix sums, sliding window, or monotonic stack\n"
    "- Use Counter / defaultdict to avoid repeated .count() calls\n"
    "- Pre-compute lookup tables instead of redundant recomputation\n\n"
    "ANTI-PATTERNS - these are NOT real optimizations, NEVER do these:\n"
    "- Do NOT replace a nested loop with list.count() - .count() is O(N), "
    "so calling it in a loop is STILL O(N^2).\n"
    "- Do NOT create variables you never use (dead code).\n"
    "- Do NOT use set() if the original preserves insertion order in lists.\n"
    "- Do NOT use `in list` checks - use `in set` or `in dict` instead for O(1) lookup.\n\n"
    "RULES - follow them strictly:\n"
    "1. Return ONLY the optimized source code. No markdown fences, no "
    "explanation, no comments about what you changed.\n"
    "2. Do NOT wrap the code in ```python``` or any other code-block markers.\n"
    "3. Keep the same function signature(s) and return type(s).\n"
    "4. Do NOT add, remove, or rename any parameters.\n"
    "5. Do NOT import modules that were not already imported in the original.\n"
    "6. If the code is already optimal, return it unchanged.\n"
    "7. The return value must be EXACTLY the same type and content for ALL inputs.\n"
    "8. If the original returns a list, the optimized must return a list with "
    "the SAME order. Do NOT change list to set.\n"
    "9. Output raw source code and absolutely nothing else."
)

CORRECTION_PROMPT: str = (
    "You are an expert algorithm engineer fixing a previous optimization attempt.\n\n"
    "Your PREVIOUS optimization was REJECTED because a formal verifier found a "
    "counterexample where the original and optimized code produce different results.\n\n"
    "RULES - follow them strictly:\n"
    "1. Return ONLY the corrected optimized source code.\n"
    "2. No markdown fences, no explanation, no comments.\n"
    "3. Keep the same function signature(s) and return type(s).\n"
    "4. Fix the specific bug described in the counterexample.\n"
    "5. The return value must be EXACTLY the same type, order, and content.\n"
    "6. Output raw source code and absolutely nothing else."
)

COMPLEXITY_PROMPT: str = (
    "You are a complexity analysis expert. Analyze the Big-O time and space "
    "complexity of the given code. Respond in EXACTLY this JSON format, "
    "nothing else:\n"
    '{"time": "O(...)", "space": "O(...)", "explanation": "one sentence"}\n'
    "Do NOT wrap in markdown. Return ONLY the JSON object."
)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def optimize_code(source_code: str, *, language: str = "python") -> str:
    """Send *source_code* to the active LLM and return the optimized version."""
    user_prompt = (
        f"Language: {language}\n\n"
        f"Optimize the following code for better Big-O complexity. "
        f"Return ONLY the raw optimized code, nothing else.\n\n"
        f"{source_code}"
    )
    raw = _chat(SYSTEM_PROMPT, user_prompt)
    return _strip_markdown_fences(raw).strip()


def optimize_with_correction(
    original_code: str,
    failed_optimized_code: str,
    counterexample: dict[str, Any],
    *,
    language: str = "python",
) -> str:
    """Counterexample-Guided Self-Correction (CGSC)."""
    ce_str = "\n".join(f"  {k} = {v}" for k, v in counterexample.items())
    user_prompt = (
        f"Language: {language}\n\n"
        f"ORIGINAL CODE (correct behaviour):\n{original_code}\n\n"
        f"YOUR PREVIOUS OPTIMIZATION (REJECTED - produces wrong output):\n"
        f"{failed_optimized_code}\n\n"
        f"COUNTEREXAMPLE (inputs where outputs differ):\n{ce_str}\n\n"
        f"Fix the optimization so it produces EXACTLY the same output as the "
        f"original for ALL inputs, including the counterexample above. "
        f"Return ONLY the corrected optimized code."
    )
    raw = _chat(CORRECTION_PROMPT, user_prompt)
    return _strip_markdown_fences(raw).strip()


def analyze_complexity(code: str, *, language: str = "python") -> dict[str, str]:
    """Ask the LLM to estimate Big-O time and space complexity."""
    try:
        _get_provider()
    except Exception as exc:
        return {"time": "N/A", "space": "N/A", "explanation": str(exc)}

    user_prompt = f"Language: {language}\n\nAnalyze this code:\n{code}"
    try:
        raw = _chat(COMPLEXITY_PROMPT, user_prompt, temperature=0.0)
        cleaned = _strip_markdown_fences(raw).strip()
        return json.loads(cleaned)
    except Exception as exc:
        logger.warning("Complexity analysis failed: %s", exc)
        return {"time": "N/A", "space": "N/A", "explanation": str(exc)}


# ---------------------------------------------------------------------------
# Provider dispatch with retry
# ---------------------------------------------------------------------------

def _chat(
    system_prompt: str,
    user_prompt: str,
    *,
    temperature: float = 0.0,
    max_tokens: int = 4096,
) -> str:
    provider, api_key, base_url, model = _get_provider()

    last_exc: Exception | None = None
    total_attempts = MAX_RETRIES + 1

    for attempt in range(1, total_attempts + 1):
        logger.info("LLM call  provider=%s  model=%s  attempt %d/%d",
                    provider, model, attempt, total_attempts)
        try:
            if provider == "gemini":
                return _call_gemini(api_key, model, system_prompt, user_prompt,
                                    temperature, max_tokens)
            return _call_openai_compatible(
                api_key, base_url, model,
                system_prompt, user_prompt, temperature, max_tokens, provider,
            )
        except _RetryableError as exc:
            wait = exc.retry_after or (20 * attempt if exc.is_rate_limit else 5 * attempt)
            logger.warning("%s on attempt %d/%d - sleeping %ds: %s",
                           "RATE LIMITED" if exc.is_rate_limit else "Transient error",
                           attempt, total_attempts, wait, exc)
            last_exc = exc
            if attempt < total_attempts:
                time.sleep(wait)
                continue
        except Exception as exc:
            # Non-retryable
            raise RuntimeError(f"LLM call failed: {exc}") from exc

    raise last_exc or RuntimeError("LLM call failed after all retries")


class _RetryableError(RuntimeError):
    def __init__(self, msg: str, *, is_rate_limit: bool = False, retry_after: int | None = None):
        super().__init__(msg)
        self.is_rate_limit = is_rate_limit
        self.retry_after = retry_after


def _call_openai_compatible(
    api_key: str, base_url: str, model: str,
    system_prompt: str, user_prompt: str,
    temperature: float, max_tokens: int, provider: str,
) -> str:
    """Call any OpenAI-compatible chat-completions endpoint via the openai SDK."""
    from openai import OpenAI
    from openai import APIStatusError, APITimeoutError, APIConnectionError, RateLimitError

    client = OpenAI(api_key=api_key, base_url=base_url, timeout=REQUEST_TIMEOUT)

    kwargs: dict[str, Any] = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user",   "content": user_prompt},
        ],
        "max_tokens": max_tokens,
    }
    # Reasoning models (o1/o3/o4/gpt-5) reject `temperature` and use
    # `reasoning_effort` instead; only pass temperature when non-default.
    if not _is_reasoning_model(model):
        kwargs["temperature"] = temperature

    try:
        resp = client.chat.completions.create(**kwargs)
    except RateLimitError as exc:
        retry_after = _parse_retry_after(exc)
        raise _RetryableError(str(exc), is_rate_limit=True, retry_after=retry_after) from exc
    except (APITimeoutError, APIConnectionError) as exc:
        raise _RetryableError(str(exc)) from exc
    except APIStatusError as exc:
        if exc.status_code in (500, 502, 503, 504):
            raise _RetryableError(str(exc)) from exc
        raise

    try:
        return resp.choices[0].message.content or ""
    except (AttributeError, IndexError) as exc:
        raise RuntimeError(f"Unexpected {provider} response: {resp}") from exc


def _call_gemini(
    api_key: str, model: str,
    system_prompt: str, user_prompt: str,
    temperature: float, max_tokens: int,
) -> str:
    """Call Google Gemini via google-genai SDK."""
    from google import genai
    from google.genai import types as genai_types

    client = genai.Client(api_key=api_key)

    config = genai_types.GenerateContentConfig(
        system_instruction=system_prompt,
        temperature=temperature,
        max_output_tokens=max_tokens,
    )

    try:
        resp = client.models.generate_content(
            model=model,
            contents=user_prompt,
            config=config,
        )
    except Exception as exc:
        msg = str(exc).lower()
        if "rate" in msg or "quota" in msg or "429" in msg:
            raise _RetryableError(str(exc), is_rate_limit=True) from exc
        if any(s in msg for s in ("500", "502", "503", "504", "timeout", "deadline")):
            raise _RetryableError(str(exc)) from exc
        raise

    text = getattr(resp, "text", None)
    if not text:
        raise RuntimeError(f"Gemini returned empty response: {resp}")
    return text


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_REASONING_PREFIXES: tuple[str, ...] = ("o1", "o3", "o4", "gpt-5")


def _is_reasoning_model(model: str) -> bool:
    m = model.lower()
    return any(m.startswith(p) for p in _REASONING_PREFIXES)


def _parse_retry_after(exc: Exception) -> int | None:
    headers = getattr(getattr(exc, "response", None), "headers", None)
    if not headers:
        return None
    val = headers.get("retry-after") or headers.get("Retry-After")
    if not val:
        return None
    try:
        return int(float(val))
    except (TypeError, ValueError):
        return None


def _strip_markdown_fences(text: str) -> str:
    """Remove accidental markdown code fences."""
    pattern = r"^```(?:\w+)?\s*\n(.*?)```\s*$"
    match = re.match(pattern, text, re.DOTALL)
    if match:
        return match.group(1)
    return text
