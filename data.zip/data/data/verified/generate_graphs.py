import matplotlib.pyplot as plt
import numpy as np

print("Generating Publication-Ready Stacked Bar Chart (11 Models, 4 Verdicts)...")

# 1. Model Names (MAI DS R1 explicitly removed)
models = [
    'GPT-5', 'Gemini 2.5 Flash', 'Codestral', 'DeepSeek R1', 
    'Grok 3', 'DeepSeek V3', 'GPT-4.1', 
    'o4-mini', 'o3', 'Gemini 2.5 Pro', 'Llama 3.1 405B'
]

# 2. Base Arrays (Index 4 removed to match the new model list)
unsat = np.array([
    22.4,  # GPT-5
    22.0,  # Gemini 2.5 Flash
    22.4,  # Codestral
    20.4,  # DeepSeek R1
    19.6,  # Grok 3
    18.8,  # DeepSeek V3
    14.0,  # GPT-4.1
    14.8,  # o4-mini
    14.8,  # o3
    16.8,  # Gemini 2.5 Pro
    16.4   # Llama 3.1 405B
])

warning = np.array([
    38.8,  # GPT-5
    25.6,  # Gemini 2.5 Flash
    24.8,  # Codestral
    32.4,  # DeepSeek R1
    28.8,  # Grok 3
    30.0,  # DeepSeek V3
    30.8,  # GPT-4.1
    32.4,  # o4-mini
    31.6,  # o3
    26.0,  # Gemini 2.5 Pro
    22.4   # Llama 3.1 405B
])

sat = np.array([
    10.4,  # GPT-5
    16.4,  # Gemini 2.5 Flash
    23.2,  # Codestral
    16.8,  # DeepSeek R1
    26.8,  # Grok 3
    21.2,  # DeepSeek V3
    18.4,  # GPT-4.1
    20.8,  # o4-mini
    18.8,  # o3
    14.8,  # Gemini 2.5 Pro
    35.2   # Llama 3.1 405B
])
# 3. The "Ceiling Math" Fix: 
# Forces every single stacked bar to hit exactly 100%.
error   = 100.0 - (unsat + warning + sat)

# Plotting
fig, ax = plt.subplots(figsize=(12, 7))

# Define strict, colorblind-friendly academic colors (Only 4 now)
colors = ['#2ca02c', '#f5b041', '#d62728', '#9467bd'] # Green, Orange, Red, Purple
labels = ['UNSAT (Provably Safe)', 'WARNING (Empirically Safe)', 'SAT (Bug Detected)', 'ERROR (Sandbox / Timeout)']

# Stacked bars (Only 4 layers)
p1 = ax.bar(models, unsat, color=colors[0], edgecolor='white', width=0.7)
p2 = ax.bar(models, warning, bottom=unsat, color=colors[1], edgecolor='white', width=0.7)
p3 = ax.bar(models, sat, bottom=unsat+warning, color=colors[2], edgecolor='white', width=0.7)
p4 = ax.bar(models, error, bottom=unsat+warning+sat, color=colors[3], edgecolor='white', width=0.7)

# Formatting
ax.set_ylabel('Percentage of Generated Code (%)', fontsize=16, fontweight='bold')
ax.set_title('Tyr Verification Verdicts Across 11 Frontier Models (N=250)', fontsize=20, fontweight='bold', pad=20)
ax.set_ylim(0, 100)
plt.xticks(rotation=45, ha='right', fontsize=14)
plt.yticks(fontsize=14)

# Legend (4 Items)
ax.legend([p1, p2, p3, p4], labels, loc='upper center', bbox_to_anchor=(0.5, -0.25), ncol=2, frameon=False, fontsize=14)

plt.tight_layout()
plt.savefig('stacked_bar_chart.png', dpi=300, bbox_inches='tight')
print("Graph saved as 'stacked_bar_chart.png'!")
plt.show()